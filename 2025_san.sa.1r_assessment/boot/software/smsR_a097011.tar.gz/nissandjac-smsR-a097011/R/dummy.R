#' Roxygen commands
#'
#' @useDynLib smsR
#'
dummy <- function() {
  return(NULL)
}

usethis::use_pipe()
